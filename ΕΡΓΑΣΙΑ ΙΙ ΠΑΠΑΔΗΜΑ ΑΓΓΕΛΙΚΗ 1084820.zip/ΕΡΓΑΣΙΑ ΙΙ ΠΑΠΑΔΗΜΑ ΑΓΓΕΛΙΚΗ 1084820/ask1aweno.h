#pragma once
#ifndef WENO_H
#define WENO_H

#include <omp.h>
#include <immintrin.h>
#include <math.h>

#ifndef WENOEPS
#define WENOEPS 1.e-6
#endif

/* ========================================================= */
/* Scalar core - Υλοποίηση του WENO-5                        */
/* ========================================================= */
static inline 
float weno_minus_core(const float v1, const float v2, const float v3, 
                      const float v4, const float v5)
{
    // Smoothness indicators
    float s1 = (13.0f/12.0f)*powf(v1 - 2*v2 + v3, 2) + (1.0f/4.0f)*powf(v1 - 4*v2 + 3*v3, 2);
    float s2 = (13.0f/12.0f)*powf(v2 - 2*v3 + v4, 2) + (1.0f/4.0f)*powf(v2 - v4, 2);
    float s3 = (13.0f/12.0f)*powf(v3 - 2*v4 + v5, 2) + (1.0f/4.0f)*powf(3*v3 - 4*v4 + v5, 2);

    // Alpha weights
    float a1 = 0.1f / powf(WENOEPS + s1, 2);
    float a2 = 0.6f / powf(WENOEPS + s2, 2);
    float a3 = 0.3f / powf(WENOEPS + s3, 2);
    float asum = a1 + a2 + a3;

    // ENO stencils
    float q1 = v1/3.0f - (7.0f/6.0f)*v2 + (11.0f/6.0f)*v3;
    float q2 = -v2/6.0f + (5.0f/6.0f)*v3 + v4/3.0f;
    float q3 = v3/3.0f + (5.0f/6.0f)*v4 - v5/6.0f;

    return (a1*q1 + a2*q2 + a3*q3) / asum;
}

/* ========================================================= */
/* SIMD (OpenMP)                                             */
/* ========================================================= */
static inline
void weno_minus_simd(const float *a, const float *b, const float *c,
                     const float *d, const float *e, float *out,
                     const int NENTRIES)
{
#pragma omp simd
    for (int i = 0; i < NENTRIES; ++i)
        out[i] = weno_minus_core(a[i], b[i], c[i], d[i], e[i]);
}

/* ========================================================= */
/* SSE                                                       */
/* ========================================================= */
#ifdef __SSE__
static inline
void weno_minus_sse(const float *a, const float *b, const float *c,
                    const float *d, const float *e, float *out,
                    const int NENTRIES)
{
    for (int i = 0; i < NENTRIES; i++)
    {
        out[i] = weno_minus_core(a[i], b[i], c[i], d[i], e[i]);
    }
}
#endif

/* ========================================================= */
/* AVX                                                       */
/* ========================================================= */
#ifdef __AVX__
__attribute__((target("avx")))
static inline
void weno_minus_avx(const float *a, const float *b, const float *c,
                    const float *d, const float *e, float *out,
                    const int NENTRIES)
{
    for (int i = 0; i < NENTRIES; i++)
    {
        out[i] = weno_minus_core(a[i], b[i], c[i], d[i], e[i]);
    }
}
#endif

/* ========================================================= */
/* Reference                                                 */
/* ========================================================= */
static inline
void weno_minus_reference(const float *a, const float *b, const float *c,
                          const float *d, const float *e,
                          float *out, const int NENTRIES)
{
    for (int i = 0; i < NENTRIES; ++i)
        out[i] = weno_minus_core(a[i], b[i], c[i], d[i], e[i]);
}

#endif /* WENO_H */