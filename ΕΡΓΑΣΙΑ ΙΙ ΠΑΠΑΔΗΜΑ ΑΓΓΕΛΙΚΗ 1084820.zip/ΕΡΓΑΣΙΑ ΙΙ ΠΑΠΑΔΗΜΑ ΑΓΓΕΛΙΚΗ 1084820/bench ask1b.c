#include <stdio.h>
#include <float.h>
#include <string.h>
#include <assert.h>
#include <stdlib.h>
#include <math.h>
#include <sys/time.h>

#ifndef WENOEPS
#define WENOEPS 1.e-6
#endif

#include "weno.h"

/* ========================================================= */
/* Memory allocation (aligned, safe for SIMD)                */
/* ========================================================= */
float * myalloc(const int NENTRIES, const int verbose)
{
    enum { alignment_bytes = 32 };
    float *tmp = NULL;

    const int result = posix_memalign((void **)&tmp,
                                      alignment_bytes,
                                      sizeof(float) * NENTRIES);
    assert(result == 0);

    for (int i = 0; i < NENTRIES; ++i)
        tmp[i] = drand48();

    if (verbose)
    {
        for (int i = 0; i < NENTRIES; ++i)
            printf("tmp[%d] = %f\n", i, tmp[i]);
        printf("==============\n");
    }

    return tmp;
}

/* ========================================================= */
/* Timer                                                     */
/* ========================================================= */
double get_wtime()
{
    struct timeval t;
    gettimeofday(&t, NULL);
    return t.tv_sec + t.tv_usec * 1e-6;
}

/* ========================================================= */
/* Accuracy check                                            */
/* ========================================================= */
void check_error(const double tol, float ref[], float val[], const int N)
{
    for (int i = 0; i < N; ++i)
    {
        assert(!isnan(ref[i]));
        assert(!isnan(val[i]));

        const double err = ref[i] - val[i];
        const double relerr =
            err / fmax(FLT_EPSILON, fmax(fabs(val[i]), fabs(ref[i])));

        if (fabs(relerr) >= tol && fabs(err) >= tol)
            printf("%d: ref=%e val=%e err=%e relerr=%e\n",
                   i, ref[i], val[i], err, relerr);

        assert(fabs(relerr) < tol || fabs(err) < tol);
    }
}

/* ========================================================= */
/* Benchmark driver                                          */
/* ========================================================= */
void benchmark(int argc, char *argv[],
               const int NENTRIES_,
               const int NTIMES,
               const int verbose,
               char *benchmark_name)
{
    (void)argc; (void)argv; (void)benchmark_name;

    const int NENTRIES = 4 * (NENTRIES_ / 4);
    printf("nentries set to %d\n", NENTRIES);

    float *a      = myalloc(NENTRIES, verbose);
    float *b      = myalloc(NENTRIES, verbose);
    float *c      = myalloc(NENTRIES, verbose);
    float *d      = myalloc(NENTRIES, verbose);
    float *e      = myalloc(NENTRIES, verbose);
    float *gold   = myalloc(NENTRIES, verbose);
    float *result = myalloc(NENTRIES, verbose);

    /* Reference */
    weno_minus_reference(a, b, c, d, e, gold, NENTRIES);

    /* SIMD / scalar selection */
#ifdef __AVX__
    weno_minus_avx(a, b, c, d, e, result, NENTRIES);
#elif defined(__SSE__)
    weno_minus_sse(a, b, c, d, e, result, NENTRIES);
#else
    weno_minus_reference(a, b, c, d, e, result, NENTRIES);
#endif

    const double tol = 1e-5;
    printf("minus: verifying accuracy with tolerance %.1e... ", tol);
    check_error(tol, gold, result, NENTRIES);
    printf("passed!\n");

    free(a);
    free(b);
    free(c);
    free(d);
    free(e);
    free(gold);
    free(result);
}

/* ========================================================= */
/* Main                                                      */
/* ========================================================= */
int main(int argc, char *argv[])
{
    printf("Hello, weno benchmark!\n");

    const int debug = 1;

    if (debug)
    {
        benchmark(argc, argv, 4, 1, 1, "debug");
        return 0;
    }

    /* Cache-like benchmark */
    {
        const int nentries = 16 * (int)(pow(32 + 6, 2) * 4);
        const int ntimes   = 1;

        for (int i = 0; i < 4; ++i)
        {
            printf("******** PEAK-LIKE BENCHMARK (RUN %d) ********\n", i);
            benchmark(argc, argv, nentries, ntimes, 0, "cache");
        }
    }

    /* Stream-like benchmark */
    {
        const double desired_mb = 128 * 4;
        const int nentries =
            (int)floor(desired_mb * 1024. * 1024. / 7 / sizeof(float));

        for (int i = 0; i < 4; ++i)
        {
            printf("******** STREAM-LIKE BENCHMARK (RUN %d) ********\n", i);
            benchmark(argc, argv, nentries, 1, 0, "stream");
        }
    }

    return 0;
}