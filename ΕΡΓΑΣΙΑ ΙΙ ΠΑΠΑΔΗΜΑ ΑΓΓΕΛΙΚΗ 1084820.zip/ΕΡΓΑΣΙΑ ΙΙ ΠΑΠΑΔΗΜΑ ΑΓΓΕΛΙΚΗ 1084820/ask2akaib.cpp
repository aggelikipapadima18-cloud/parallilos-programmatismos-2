#include <iostream>
#include <cuda_runtime.h>
#include <cublas_v2.h>

// --- Ερώτημα (β): Custom Kernel για τον τελικό συνδυασμό ---
// Πραγματοποιεί τις πράξεις E = AC - BD και F = AD + BC στο Device
__global__ void combineResultsKernel(float* AC, float* BD, float* AD, float* BC, float* E, float* F, int N) {
    int row = blockIdx.y * blockDim.y + threadIdx.y;
    int col = blockIdx.x * blockDim.x + threadIdx.x;
    
    if (row < N && col < N) {
        int idx = row * N + col;
        E[idx] = AC[idx] - BD[idx];
        F[idx] = AD[idx] + BC[idx];
    }
}

int main() {
    int N = 1024; // Διάσταση πίνακα NxN
    size_t size = N * N * sizeof(float);

    // --- Ερώτημα (α): Host Allocation & Initialization ---
    float *h_A = (float*)malloc(size);
    float *h_B = (float*)malloc(size);
    float *h_C = (float*)malloc(size);
    float *h_D = (float*)malloc(size);

    for (int i = 0; i < N * N; i++) {
        h_A[i] = 1.0f; h_B[i] = 0.5f; 
        h_C[i] = 2.0f; h_D[i] = 1.0f;
    }

    // --- Ερώτημα (α): Device Allocation ---
    float *d_A, *d_B, *d_C, *d_D, *d_E, *d_F;
    float *d_AC, *d_BD, *d_AD, *d_BC;

    cudaMalloc(&d_A, size); cudaMalloc(&d_B, size);
    cudaMalloc(&d_C, size); cudaMalloc(&d_D, size);
    cudaMalloc(&d_E, size); cudaMalloc(&d_F, size);
    cudaMalloc(&d_AC, size); cudaMalloc(&d_BD, size);
    cudaMalloc(&d_AD, size); cudaMalloc(&d_BC, size);

    // Μεταφορά από Host στο Device
    cudaMemcpy(d_A, h_A, size, cudaMemcpyHostToDevice);
    cudaMemcpy(d_B, h_B, size, cudaMemcpyHostToDevice);
    cudaMemcpy(d_C, h_C, size, cudaMemcpyHostToDevice);
    cudaMemcpy(d_D, h_D, size, cudaMemcpyHostToDevice);

    // --- Ερώτημα (β): Υλοποίηση με cuBLAS ---
    cublasHandle_t handle;
    cublasCreate(&handle);
    float alpha = 1.0f, beta = 0.0f;

    // Πολλαπλασιασμοί (Χρήση Hint για Column-Major: Εκτελούμε C*A για να πάρουμε το Row-Major AC)
    cublasSgemm(handle, CUBLAS_OP_N, CUBLAS_OP_N, N, N, N, &alpha, d_C, N, d_A, N, &beta, d_AC, N);
    cublasSgemm(handle, CUBLAS_OP_N, CUBLAS_OP_N, N, N, N, &alpha, d_D, N, d_B, N, &beta, d_BD, N);
    cublasSgemm(handle, CUBLAS_OP_N, CUBLAS_OP_N, N, N, N, &alpha, d_D, N, d_A, N, &beta, d_AD, N);
    cublasSgemm(handle, CUBLAS_OP_N, CUBLAS_OP_N, N, N, N, &alpha, d_C, N, d_B, N, &beta, d_BC, N);

    // Κλήση Kernel για τον τελικό συνδυασμό των 4 πινάκων
    dim3 threads(16, 16);
    dim3 blocks((N + 15) / 16, (N + 15) / 16);
    combineResultsKernel<<<blocks, threads>>>(d_AC, d_BD, d_AD, d_BC, d_E, d_F, N);

    // Μεταφορά αποτελεσμάτων στον Host
    float *h_E = (float*)malloc(size);
    float *h_F = (float*)malloc(size);
    cudaMemcpy(h_E, d_E, size, cudaMemcpyDeviceToHost);
    cudaMemcpy(h_F, d_F, size, cudaMemcpyDeviceToHost);

    std::cout << "Ο υπολογισμός ολοκληρώθηκε!" << std::endl;

    // Cleanup
    cublasDestroy(handle);
    cudaFree(d_A); cudaFree(d_B); cudaFree(d_C); cudaFree(d_D);
    cudaFree(d_E); cudaFree(d_F); cudaFree(d_AC); cudaFree(d_BD);
    cudaFree(d_AD); cudaFree(d_BC);
    free(h_A); free(h_B); free(h_C); free(h_D); free(h_E); free(h_F);

    return 0;
}